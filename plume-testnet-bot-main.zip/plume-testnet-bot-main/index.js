const axios = require('axios');
const { createWallet, getAddress } = require('./src/wallet');
const { provider, CONTRACT_ADDRESS } = require('./src/config');

const TelegramBot = require("node-telegram-bot-api");

const token = process.env.TELEGRAM_BOT_TOKEN;
const bot = new TelegramBot(token, { polling: true });

(async () => {
  

  //Bot chào khi ấn start
  bot.on('message',(msg)=>{
    const chatId = msg.chat.id
    switch(msg.text){
      case '/start':
        bot.sendMessage(chatId, 'Bot is made by Chau Au Em Re');
        bot.sendMessage(chatId, 'Enter the private key to start the faucet');
        break
      
        default:
          break
    }
  })

  //Bot rep khi nhap private key

  bot.on("message", async (msg) => {
    const { chat: { id }, text } = msg;
    const msgText = text;
    try {
      // Lay dia chi vi 
      const walletAddress = getAddress(msgText, provider);
      bot.sendMessage(id,`Using wallet address: ${walletAddress}`);
      bot.sendMessage(id,'Sending transaction...');

        //Data 
      const { data } = await axios.post(
      'https://faucet.plumenetwork.xyz/api/faucet',
      {
        walletAddress,
        token: 'ETH',
      }
      );
       //Tao vi va transaction
        const { salt, signature } = data;

        const wallet = createWallet(msgText, provider);
        const transactionData = `0x103fc4520000000000000000000000000000000000000000000000000000000000000060${salt.substring(
    2
  )}00000000000000000000000000000000000000000000000000000000000000a0000000000000000000000000000000000000000000000000000000000000000345544800000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000041${signature.substring(
    2
  )}00000000000000000000000000000000000000000000000000000000000000`;

// Qua trinh Faucet

const nonce = await wallet.getNonce();
const feeData = await wallet.provider.getFeeData();
const gasLimit = await wallet.estimateGas({
  data: transactionData,
  to: CONTRACT_ADDRESS,
});
const gasPrice = feeData.gasPrice;

const transaction = {
  data: transactionData,
  to: CONTRACT_ADDRESS,
  gasLimit,
  gasPrice,
  nonce,
  value: 0,
};
const result = await wallet.sendTransaction(transaction);
const a = result.from;
const b = result.hash;
bot.sendMessage(id,`0.001 ETH sent to ${a}`);
bot.sendMessage(id,`Transaction hash : https://testnet-explorer.plumenetwork.xyz/tx/${b}`);
bot.sendMessage(id,"You can only claim from the faucet every 1 hour");
    } catch (error) {
      bot.sendMessage(id, `${text} Error `);
    }
  });
}
)();
