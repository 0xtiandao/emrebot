require('dotenv').config();
const { JsonRpcProvider } = require('ethers');
const { PLUME_ABI } = require('./abi');

const RPC_URL = 'https://testnet-rpc.plumenetwork.xyz/http';
const CONTRACT_ADDRESS = PLUME_ABI.at(-1).CA;
const provider = new JsonRpcProvider(RPC_URL);

module.exports = { RPC_URL, CONTRACT_ADDRESS, provider };
